DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': '',
        'USER': 'tom',
        'PASSWORD': 'tom',
        'HOST': 'localhost',
        'PORT': '5432'
        }
}
