#include "Class.hpp"

Class::Class(){
}

Class::~Class(){
}
