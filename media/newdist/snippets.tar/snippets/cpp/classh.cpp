#ifndef CLASS_HPP
#define CLASS_HPP

class CLASS{
public:
	CLASS();
	~CLASS();
};

#endif
